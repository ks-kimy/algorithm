def frog_jump(arr):
    temp_sum = 0
    position = 0
    temp_position = 0 #이전 위치 값 저장 용도.
    direction = 0
    for i in range(K): # K 번 점프. 계산
        if arr[temp_position] < 0:
            direction -= 1
            temp = arr[temp_position] # 이전 값의 값 임시저장.
        elif arr[temp_position] > 0:
            direction = 0

        if direction == -1:
            temp_position = position
            position = position + arr[position] - temp # 이전 값이 음수였기 때문에 - 로 계산
        elif direction <= -2:
            temp_position = position
            position += -arr[temp_position]
        elif direction == 0:
            temp_position = position
            position += arr[position]

        if position >= 0:
            temp_sum += arr[position]
        if position < 0:
            return temp_sum
        # 위치가 음수면 그 때의 값을 출력
        # 위치가 0이거나 양수면 계속해서 진행
    return temp_sum





T = int(input())
for tc in range(T):
    N, K = map(int, input().split())
    arr = list(map(int, input().split()))
    result = frog_jump(arr)
    print(f'#{tc+1} {result}')